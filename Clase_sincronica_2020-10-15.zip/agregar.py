def agregar_al_final(arreglo,valor,cantidad_elementos,cantidad_maxima):
    nueva_cantidad = cantidad_elementos
    if (cantidad_elementos < cantidad_maxima):
        arreglo[cantidad_elementos] = valor
        nueva_cantidad = cantidad_elementos + 1
    return  nueva_cantidad


def insertar(arreglo,valor,posicion, cantidad_elementos,cantidad_maxima,valor_min,valor_max):
    nueva_cantidad = cantidad_elementos
    if (cantidad_elementos < cantidad_maxima and posicion >= 0 and posicion < cantidad_elementos and
            valor >= valor_min and valor <= valor_max):
        for i in range(cantidad_elementos,posicion,-1):
            arreglo[i] = arreglo[i - 1]
        arreglo[posicion] = valor
        nueva_cantidad = cantidad_elementos + 1
    return  nueva_cantidad


def agregar_ordenado(arreglo,valor,cantidad_elementos,cantidad_maxima,valor_min,valor_max):
    nueva_cantidad = cantidad_elementos
    if (cantidad_elementos < cantidad_maxima):
        # Buscar el punto de insercion - Intento secuencial
        i = 0
        while (i < cantidad_elementos) and (arreglo[i] < valor):
            i +=1
        punto_de_insercion = i
        nueva_cantidad = insertar(arreglo,valor,punto_de_insercion,cantidad_elementos,cantidad_maxima,valor_min,valor_max)
    return  nueva_cantidad
