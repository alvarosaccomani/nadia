import cargas
import mostrar_vector

def orden_generico(arreglo,cant_elementos,metodo,orden):
    if(metodo == "B"):
        print("Metodo bubuja")
    elif (metodo == "I"):
        print("Insersion")
    else:
        print("Seleccion")
    if (orden == "A"):
        print("Ascendente")
    else:
        print("Desendente")




vector = [0] * 100
cant_real = 5
cargas.carga_aleatoria_int(vector,cant_real,1,100)
mostrar_vector.mostrar(vector,cant_real)
print('------ dando vuelta ----')
aux = vector[cant_real - 1]
for i in range(cant_real - 1,0,-1):
    vector[i] = vector[i - 1]
vector[0] = aux
mostrar_vector.mostrar(vector,cant_real)
orden_generico(vector,cant_real,"B","D")
print("-- Ordenado --")
mostrar_vector.mostrar(vector,cant_real)



