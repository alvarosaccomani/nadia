import menu_consola
import cargas
import mostrar_vector
import busqueda
import agregar
import eliminacion
import ordenamiento

cantidad_maxima = 1000
edades = [0] * cantidad_maxima
cant_real = 15

opcion = 0
while opcion != 20:
    print("Elegiste ",opcion)
    opcion = menu_consola.menu()
    if opcion == 1:
        # - Decidir tamaño
        cant_real = int(input('Que cantidad de elementos quieres usar : '))
        if (cant_real > cantidad_maxima):
            print('No tengo tanto espacio, lo siento....')

    elif opcion == 2:
        # - cargar arreglo manualmente
        cargas.carga_manual_int(edades,cant_real,1,100)
    elif opcion == 3:
        # - cargar arreglo aleatorio
        cargas.carga_aleatoria_int(edades,cant_real,1,100)
    elif opcion == 4:
        # - mostrar arreglo
        mostrar_vector.mostrar(edades, cant_real)
    elif opcion == 5:
        # - Buscar un numero dentro del arreglo
        a_buscar = int(input('Que numero desea encontrar : '))
        posicion = busqueda.busqueda_secuencial(edades,a_buscar,cant_real)
        if (posicion > -1):
            print("Numero encontrado en la posicion : ",posicion)
        else:
            print('No se ha encontrado, lo siento....')

    elif opcion == 6:
        # - Eliminar un valor
        mostrar_vector.mostrar(edades, cant_real)
        posicion_a_borrar = int(input("Cual es la posición del valor a borrar : ")) # 3
        cant_real = eliminacion.eliminar_por_posicion(edades,posicion_a_borrar - 1,cant_real)
    elif opcion == 7:
        # - Insertar un valor en una posicion
        a_agregar = int(input('Que numero desea agregar : '))
        mostrar_vector.mostrar(edades, cant_real)
        posicion_a_agregar = int(input("Cual es la posición del valor a agregar : "))
        cant_real = agregar.insertar(edades,a_agregar,posicion_a_agregar - 1,cant_real,cantidad_maxima,1,100)
    elif opcion == 8:
        # - Agregar al final
        a_agregar = int(input('Que numero desea agregar : '))
        cant_real = agregar.agregar_al_final(edades,a_agregar,cant_real,cantidad_maxima)
    elif opcion == 9:
        ordenamiento.ordenar_seleccion(edades,cant_real)
    elif opcion == 10:
        ordenamiento.ordenar_burbuja_mejorada(edades,cant_real)
    elif opcion == 11:
        ordenamiento.ordenar_insercion(edades,cant_real)
    elif opcion == 12:
        a_buscar = int(input('Que numero desea encontrar (binario) : '))
        posicion = busqueda.busqueda_binaria(edades,a_buscar,cant_real)
        if (posicion > -1):
            print("Numero encontrado en la posicion : ",posicion)
        else:
            print('No se ha encontrado, lo siento....')
    elif opcion == 13:
        # - Insertar un valor en una ordenado
        a_agregar = int(input('Que numero desea agregar : '))
        cant_real = agregar.agregar_ordenado(edades,a_agregar,cant_real,cantidad_maxima,1,100)
    input("presione ENTER para continuar ....")



print("Gracias por usar el fabuloso programa!!!")