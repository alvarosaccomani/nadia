import os
import busqueda
def menu():
    opcion = '0'
    opciones = ['1','2','3','4','5','6','7','8','9','10','11','12','13','20']

    while (busqueda.busqueda_secuencial(opciones,opcion,len(opciones)) < 0):
        os.system("clear") #en Windows es "cls"
        print("----------------------------------------------")
        print("- Binvenidos a mi fabuloso programa          -")
        print("----------------------------------------------")
        print("- Este es el menú de opciones                -")
        print("----------------------------------------------")
        print("-¿ Que quieres hacer ?                       -")
        print("----------------------------------------------")
        print("- 1 - Decidir el tamaño del arreglo (max 100) ")
        print("- 2 - Cargar el arreglo manualmente ")
        print("- 3 - Cargar el arreglo aleatoriamente ")
        print("- 4 - Mostrar arreglo ")
        print("- 5 - Buscar un numero dentro del arreglo ")
        print("- 6 - Eliminar un valor ")
        print("- 7 - Insertar un valor en una posicion ")
        print("- 8 - Agregar al final ")
        print("- 9 - Ordenar por Seleccion ")
        print("- 10 - Ordenar por Burbuja Mejorada ")
        print("- 11 - Ordenar por Insercion ")
        print("- 12 - Busqueda binaria ")
        print("- 13 - Insertar Ordenado ")
        print("----------------------------------------------")
        print("- 20 - Salir ")
        print("----------------------------------------------")
        opcion = input("Dime tu opción : ")

    return int(opcion)
