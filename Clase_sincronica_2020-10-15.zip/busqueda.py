def busqueda_secuencial(arreglo,valor_a_buscar,cantidad_de_elementos):
    #Busqueda secuencial
    i = 0 #Indice
    respuesta = -1
    while (i < cantidad_de_elementos) and (arreglo[i] != valor_a_buscar):
        i +=  1
    if (i < cantidad_de_elementos):
        #devolver posicion
        respuesta = i

    return respuesta

def busqueda_binaria(arreglo,valor_a_buscar,cantidad_de_elementos):
    encontrado = False
    respuesta = -1
    numero_inicial = 0
    numero_final = cantidad_de_elementos - 1
    mitad = (numero_final - numero_inicial) // 2
    while not encontrado and (numero_final >= numero_inicial):
        #mitad = (numero_final - numero_inicial) // 2
        print("Buscando en posicion ",mitad,arreglo[mitad])
        if (arreglo[mitad] == valor_a_buscar):
            encontrado = True
            respuesta = mitad
            print("Encontrado en posicion ",mitad,arreglo[mitad])
        else:
            if (arreglo[mitad] < valor_a_buscar):
                mitad += 1
                numero_inicial = mitad
                mitad = mitad + ((numero_final - numero_inicial) // 2)
                print("Me quedo con la parte derecha ")
            else:
                mitad -= 1
                numero_final = mitad
                mitad = mitad - ((numero_final - numero_inicial) // 2)
                print("Me quedo con la parte izquierda ")
    return respuesta