# Segundo Parcial
# Autor : Walter Panessi
# Ejercicio 2

from pyrecord import Record
import numpy as np
import random

Stock = Record.create_type('Stock','marca','procesador','memoria', 'disco',
                            marca = ' ',procesador = ' ', memoria = ' ', disco = ' ' )

def crear_vector(vector,cantidad):
    for i in range(cantidad):
        vector[i] = Stock()
        carga_aleatoria(vector[i])
    return i + 1

def carga_aleatoria(registro):
    registro.marca = random.choice(['Asus','Dell','Lenovo','Mac','Toshiba'])
    registro.procesador = random.choice(['I9','I7','I5','Ryzen 7','Ryzen 5'])
    registro.memoria = random.choice([' 4 GB', ' 8 GB', '16 GB'])
    registro.disco = random.choice([' 250 GB',' 500 GB', '1 TB'])

def imprimir(vector,cantidad):
    print('marca / procesador / memoria memoria / disco disco')
    for i in range(cantidad):
        print(vector[i].marca,end = " / ")
        print(vector[i].procesador,end = " / ")
        print(vector[i].memoria,end = " / ")
        print(vector[i].disco)

def completar(texto,cantidad):
    texto_nuevo = texto
    for i in range(cantidad - len(texto)):
        texto_nuevo += " "
    return texto_nuevo

def completar_invertido(texto,cantidad):
    texto_nuevo = ""
    for i in range(len(texto)):
        texto_nuevo += chr(ord('z') - ord(texto[i]))
    for i in range(cantidad - len(texto)):
        texto_nuevo += 'z'
    return texto_nuevo

def ordenar_vector(vector,elementos):
    se_hizo_un_cambio = True
    while se_hizo_un_cambio:
        se_hizo_un_cambio = False
        i = 1  
        while i < elementos:
            clave1 = completar_invertido(vector[i - 1].marca,20)  + completar(vector[i - 1].procesador,15) + completar(vector[i - 1].memoria,5) + completar(vector[i - 1].disco,5)
            clave2 = completar_invertido(vector[i].marca,20)  + completar(vector[i].procesador,15)+ completar(vector[i].memoria,5) + completar(vector[i].disco,5)
            if clave1 > clave2:
                se_hizo_un_cambio = True
                aux = vector[i - 1]
                vector[i - 1] = vector[i]
                vector[i] = aux
            i += 1

def calcular_stock(vector,elementos):
    marca = vector[0].marca
    i = 0
    total = 0
    while i < elementos:
        totalM = 0
        marca = vector[i].marca
        print("Stock de la Marca : ", marca)
        while i < elementos and vector[i].marca == marca:
            totalP = 0
            procesador = vector[i].procesador
            print("   Procesador : ", procesador)
            while i < elementos and vector[i].marca == marca and procesador == vector[i].procesador:
                totalR = 0
                memoria = vector[i].memoria
                print("     Memoria : ", memoria )
                while i < elementos and vector[i].marca == marca and procesador == vector[i].procesador and memoria == vector[i].memoria:
                    totalD = 0
                    disco = vector[i].disco
                    while i < elementos and vector[i].marca == marca and procesador == vector[i].procesador and memoria == vector[i].memoria and disco == vector[i].disco:
                        totalD += 1
                        i += 1
                    print("         Con disco : ",disco,totalD)
                    totalM += totalD
                    totalP += totalD
                    totalR += totalD
                    total += totalD
                print("     Con Memoria : ",memoria,totalR)
            print("  Con Procesador : ",procesador,totalP)
        print("Marca : ",marca,totalM)
    print("Total en stock : ",total)
                    


  
def main():
    cantidad = 1500
    stock = np.empty([cantidad,], dtype=Stock)
    cantidad_real = crear_vector(stock,1500)
    print(" ---- Se imprimen los primeros 20 productos ---- ")
    imprimir(stock,20)
    
    print(" ---- Ordenando. Esto puede tardar ---- ")
    ordenar_vector(stock,cantidad_real)
    print(" ---- Calculando Stock ---- ")
    calcular_stock(stock,cantidad_real)

if __name__ == "__main__":
    main()